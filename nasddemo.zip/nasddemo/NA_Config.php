<?php
//定义参数
define("NA_APIKEY",'28986366-c024-4326-aa18-d1b08df6c294');//定义商家key
define("NA_BUID",'553747');//定义商家ID
define("NA_URL","https://api.na12345.com");//平台域名